﻿//Author: Sovanmearlea Hor
//Date: October 22, 2019
//Assignment: Homework 4
//http://fa19horsovanmearleahw4.azurewebsites.net/
//Description: This program shows a toy store product array to customers and allows admins to make changes to products and users.

using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;

namespace Hor_Sovanmearlea_HW4.Controllers
{
    public class HomeController : Controller
    {
        //displays index view
        public IActionResult Index()
        {
            return View();
        }

        //displays products view
        public IActionResult ViewProducts()
        {
            return View("Index");
        }
    }
}