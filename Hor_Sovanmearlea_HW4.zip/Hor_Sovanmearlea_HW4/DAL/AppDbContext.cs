﻿//Author: Sovanmearlea Hor
//Date: October 22, 2019
//Assignment: Homework 4
//Description: This program shows a toy store product array to customers and allows admins to make changes to products and users.

using System;
using Microsoft.EntityFrameworkCore;

using Hor_Sovanmearlea_HW4.Models;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;

namespace Hor_Sovanmearlea_HW4.DAL
{
    //NOTE: This class definition references the user class for this project. 
    public class AppDbContext : IdentityDbContext<AppUser>
    {
        public AppDbContext(DbContextOptions<AppDbContext> options) : base(options) { }

        //Add Dbsets here. 
        public DbSet<Product> Products { get; set; }
    }
}
