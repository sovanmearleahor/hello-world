﻿
//Author: Sovanmearlea Hor
//Date: October 22, 2019
//Assignment: Homework 4
//Description: This program shows a toy store product array to customers and allows admins to make changes to products and users.

using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using System.ComponentModel.DataAnnotations;

namespace Hor_Sovanmearlea_HW4.Models
{
    public class AppUser : IdentityUser
    {
        //adding fields that are not already in identity
        [Required(ErrorMessage = "First name is required.")]
        [Display(Name = "First Name")]
        public String FirstName { get; set; }

         [Required(ErrorMessage = "Last Name is required.")]
         [Display(Name = "Last Name")]
         public String LastName { get; set; }
    }
}
