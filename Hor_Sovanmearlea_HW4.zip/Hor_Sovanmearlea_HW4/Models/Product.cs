﻿//Author: Sovanmearlea Hor
//Date: October 22, 2019
//Assignment: Homework 4
//Description: This program shows a toy store product array to customers and allows admins to make changes to products and users.

using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace Hor_Sovanmearlea_HW4.Models
{
    //gets data from user when creating a product and stores it
    public class Product
    {
        public int ProductID { get; set; }

        [Required(ErrorMessage ="Name is required.")]
        [Display(Name = "Product Name")]
        public String ProductName { get; set; }

        [Display(Name = "Description")]
        public String Description { get; set; }

        [Required(ErrorMessage = "Price is required.")]
        [Display(Name = "Product Price")]
        [DisplayFormat(DataFormatString ="{0:c}")]
        public Decimal ProductPrice { get; set; }

    }
}
